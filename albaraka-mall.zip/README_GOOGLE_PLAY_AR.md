# تجهيز البركة مول لجوجل بلاي

- `applicationId`: `com.albaraka.mall`
- `versionCode`: `2`
- `versionName`: `1.0.1`
- `targetSdk`: `35`
- إخراج Google Play: Android App Bundle (`.aab`)
- الإصدار Release يعتمد على مفتاح توقيع خارجي ولا يحفظ كلمة السر داخل المشروع.

## أسرع طريقة عبر GitHub Actions

أنشئ Secrets في المستودع بالأسماء التالية:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

ثم شغّل Workflow باسم **Build Albaraka Mall for Google Play** من Actions.

## إنشاء مفتاح رفع جديد مرة واحدة

على جهاز به Java/JDK:

```bash
keytool -genkeypair -v -keystore albaraka-upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias albaraka-upload
base64 -w 0 albaraka-upload.jks > albaraka-upload.base64.txt
```

احتفظ بملف `albaraka-upload.jks` وكلمات السر في مكان آمن. لا ترفعها إلى GitHub داخل المستودع.

بعد نجاح Workflow، نزّل ملف `.aab` من Artifacts وارفعه إلى Google Play Console.
