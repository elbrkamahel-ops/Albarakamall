# تطبيق مول البركة - Android

تطبيق Android خفيف يفتح متجر مول البركة الحالي داخل WebView مع الحفاظ على تسجيل الدخول والسلة والطلبات وبيانات الموقع.

**رابط المتجر:** https://albarakamall.wuaze.com/

## تم تجهيزه
- اسم التطبيق: مول البركة
- الوضع الرأسي للموبايل
- JavaScript وDOM Storage وCookies مفعّلة لدعم المتجر
- زر الرجوع يرجع داخل صفحات المتجر قبل إغلاق التطبيق
- الروابط الخارجية تفتح خارج التطبيق
- دعم فتح الملفات/التحميلات من الموقع
- HTTPS فقط

## إخراج APK / AAB
المشروع يحتاج Android SDK وGradle/Android Studio أو بيئة Android build على جهاز قادر على البناء. بعد فتح المشروع اختر:
- Build > Generate Signed Bundle / APK
- APK للتثبيت المباشر
- Android App Bundle (AAB) للنشر على Google Play

هذا المشروع لا يحتوي مفاتيح توقيع Google Play.
